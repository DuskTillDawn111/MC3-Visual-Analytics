<script setup lang="ts">
import { computed,ref,watch } from 'vue'
import { get } from '../api'
import type { Message,Page,TopicData } from '../api'
import { filters,palette,selection,exportJson } from '../store'
const props=defineProps<{revision:number}>()
const emit=defineEmits<{evidence:[id:string]}>()
type TopicModelData=TopicData & {assignments:{message_id:string;weights:number[]}[]}
const data=ref<TopicModelData>(),topicCount=ref(6),chosen=ref(0),busy=ref(false),error=ref('')
const chosenGroup=ref<number|null>(null),groupSamples=ref<Message[]>([]),samplesBusy=ref(false)
let request=0,sampleRequest=0
const selected=computed(()=>data.value?.topics[chosen.value])
const selectedGroup=computed(()=>data.value?.groups.find(group=>group.id===chosenGroup.value))
const selectedIds=computed(()=>selectedGroup.value?.message_ids[chosen.value]||selected.value?.message_ids||[])
const selectedSamples=computed(()=>selectedGroup.value?groupSamples.value:selected.value?.representatives||[])
const selectedScope=computed(()=>({topic_id:chosen.value,group_id:selectedGroup.value?.id??null,
  members:selectedGroup.value?.members||[],message_ids:selectedIds.value,sample_ids:selectedSamples.value.map(m=>m.id)}))
const maxCell=computed(()=>Math.max(1,...(data.value?.groups.flatMap(g=>g.counts)||[])))
const maxDay=computed(()=>Math.max(1,...(data.value?.daily.map(d=>d.counts.reduce((a,b)=>a+b,0))||[])))
async function load(){
 const current=++request
 ++sampleRequest;chosenGroup.value=null;groupSamples.value=[];samplesBusy.value=false
 busy.value=true;error.value=''
 try{const result=await get<TopicModelData>('topics',{...filters.value,topic_count:topicCount.value});if(current===request){data.value=result;if(chosen.value>=result.topics.length)chosen.value=0}}
 catch(e){if(current===request)error.value=(e as Error).message}
 finally{if(current===request)busy.value=false}
}
watch(()=>props.revision,load,{immediate:true})
watch(topicCount,()=>{selection.messageIds=[];load()})
async function selectTopic(index:number,groupId:number|null=null){
 const current=++sampleRequest
 chosen.value=index;chosenGroup.value=groupId;groupSamples.value=[];samplesBusy.value=false;error.value=''
 const ids=[...selectedIds.value]
 selection.messageIds=ids
 if(ids[0])emit('evidence',ids[0])
 if(!selectedGroup.value||!ids.length)return
 const allowed=new Set(ids)
 const ranked=data.value!.assignments.filter(row=>allowed.has(row.message_id))
  .sort((a,b)=>(b.weights[index]||0)-(a.weights[index]||0)||a.message_id.localeCompare(b.message_id))
  .slice(0,3).map(row=>row.message_id)
 samplesBusy.value=true
 try{
  const records=await get<Page<Message>>('messages',{...filters.value,ids:ranked.join(','),page_size:3})
  if(current===sampleRequest){
   const byId=new Map(records.items.map(message=>[message.id,message]))
   groupSamples.value=ranked.flatMap(id=>byId.has(id)?[byId.get(id)!]:[])
  }
 }catch(e){if(current===sampleRequest)error.value=(e as Error).message}
 finally{if(current===sampleRequest)samplesBusy.value=false}
}
function exportModel(){if(data.value)exportJson('mc3-topics.json',{...data.value,selected_scope:selectedScope.value})}
function chooseDay(day:string){selection.start=day;selection.end=day;selection.hour=null}
function barY(counts:number[],i:number){return 98-counts.slice(0,i+1).reduce((a,b)=>a+b,0)/maxDay.value*82}
</script>
<template><div class="topic-view" :aria-busy="busy"><div class="topic-toolbar"><label>主题数 <select aria-label="主题数量" v-model.number="topicCount"><option v-for="n in [4,6,8]" :key="n" :value="n">{{n}}</option></select></label><span>TF-IDF + NMF · 全量拟合，当前范围聚合</span><button class="chip" :disabled="!data||busy||samplesBusy" @click="exportModel">导出模型与来源</button></div><div v-if="error" class="error" role="alert">{{error}}</div><div v-if="busy&&!data" class="empty">正在计算官方通信主题…</div><template v-if="data"><p class="topic-note">{{data.total}} 条当前通信，{{data.unassigned}} 条未归类。按最大相对主题权重分组；主题是探索线索，权重不代表概率。</p><p class="topic-note" data-testid="topic-reliability">主题对训练样本与初始化敏感；编号不是固定类别，切换主题数后不可按编号对照。请结合关键词和原文解释，不把主题当作组织或事实标签。</p><div class="topic-layout"><div><div class="topic-table scroll"><table data-testid="topic-matrix"><thead><tr><th>当前窗口群体</th><th v-for="t in data.topics" :key="t.id"><button :disabled="busy" @click="selectTopic(t.id)" :title="t.keywords.join(' / ')"><i :style="{background:palette[t.id%palette.length]}"></i>主题 {{t.id+1}}<small>{{t.keywords.slice(0,2).join(' / ')}}</small></button></th></tr></thead><tbody><tr v-for="g in data.groups" :key="g.id"><th :title="g.members.join('、')"><i :style="{background:palette[g.id%palette.length]}"></i>社区 {{g.id+1}}<small>{{g.members.length}} 个主体</small></th><td v-for="(count,index) in g.counts" :key="index"><button data-testid="topic-cell" :data-count="count" :disabled="!count||busy" :aria-label="`社区 ${g.id+1} 主题 ${index+1}，${count} 条通信`" :style="{background:count?`rgba(75,126,161,${.08+.72*count/maxCell})`:'#f5f7f9',color:count/maxCell>.5?'#fff':'#476781'}" @click="selectTopic(index,g.id)">{{count||'·'}}</button></td></tr></tbody></table></div><p class="topic-note">跨社区通信会出现在双方群体中，不能将群体行相加作为唯一消息总数。</p><h3>主题随时间变化</h3><svg class="topic-timeline" viewBox="0 0 728 127" aria-label="每日主题分布"><g v-for="(day,index) in data.daily" :key="day.date" role="button" tabindex="0" :aria-label="`${day.date} 主题分布`" @click="chooseDay(day.date)" @keydown.enter.prevent="chooseDay(day.date)" class="topic-day"><rect :x="index*51+12" y="10" width="33" height="90" fill="#f7f9fb"/><rect v-for="(count,i) in day.counts" :key="i" :x="index*51+12" :y="barY(day.counts,i)" width="33" :height="count/maxDay*82" :fill="palette[i%palette.length]" :opacity="chosen===i?1:.4"/><text :x="index*51+28" y="119" text-anchor="middle" font-size="10" fill="#7b8997">{{day.date.slice(5)}}</text><title>{{day.date}} · {{day.counts.reduce((a,b)=>a+b,0)}} 条</title></g></svg></div><aside class="topic-description" v-if="selected"><div class="topic-name"><i :style="{background:palette[chosen%palette.length]}"></i><h3>{{selectedGroup?`社区 ${selectedGroup.id+1} · `:''}}主题 {{chosen+1}}</h3><span>{{selectedIds.length}} 条</span></div><p class="topic-note" data-testid="topic-selection-scope">{{selectedGroup?`当前筛选内的社区 ${selectedGroup.id+1}；计数、样本与所选证据使用相同消息范围。`:'当前筛选内的全部群体。'}}</p><div class="keywords"><button v-for="word in selected.keywords" :key="word" class="chip" @click="selection.q=word">{{word}}</button></div><p class="topic-note">关键词来自全量主题模型，可用于检索；下列为{{selectedGroup?'所选群体内':'当前筛选内'}}此主题权重最高的原文样本。</p><div v-if="samplesBusy" class="topic-note" role="status">正在读取所选群体的原文样本…</div><button v-for="m in selectedSamples" :key="m.id" class="topic-sample" @click="emit('evidence',m.id)" data-testid="topic-sample"><span class="mono">{{m.id}} ↗</span><small>{{m.sender}} → {{m.receiver}} · {{m.timestamp}}</small><p>{{m.content}}</p></button><div v-if="!selectedIds.length" class="empty">当前范围没有此主题的消息。</div></aside></div><details class="model-note"><summary>模型范围与可复现参数</summary><p>模型 {{data.model.version}} · seed {{data.model.seed}} · 主题数 {{data.model.topic_count}}。从全部 584 条官方通信移除实体名称与英语缩写碎片后拟合 TF-IDF + NMF，日期与主体筛选不重训。重构误差 {{data.model.reconstruction_error}}，它不能单独证明主题质量。</p><p class="mono">原始 ZIP SHA-256：{{data.model.source_sha256}}</p></details></template></div></template>
<style scoped>
.topic-view{padding:12px 14px}.topic-toolbar{display:flex;align-items:center;gap:12px;font-size:12px;color:#748191;flex-wrap:wrap}.topic-toolbar label{display:flex;gap:6px;align-items:center}.topic-toolbar select{padding:4px 8px}.topic-toolbar>.chip{margin-left:auto}.topic-note{font-size:12px;color:#7a8897;line-height:1.8;margin:10px 0}.topic-layout{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(230px,1fr);gap:20px}.topic-table table{width:100%;border-spacing:4px;table-layout:fixed;font-size:12px}.topic-table th{font-weight:500;color:#61758a;text-align:center}.topic-table th:first-child{width:100px;text-align:left}.topic-table th>button{background:none;border:0;padding:6px 0;font-size:12px;width:100%}.topic-table small{display:block;font-size:10px;line-height:1.5;color:#8795a4;margin-top:5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.topic-table td{padding:0}.topic-table td button{height:42px;width:100%;border:0;border-radius:2px;font-variant-numeric:tabular-nums;font-size:14px}.topic-table td button:disabled{opacity:1;cursor:default}.topic-table i,.topic-name i{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:5px}.topic-layout h3{font-size:13px;font-weight:600;color:#526980;margin:15px 0 8px}.topic-timeline{width:100%;display:block}.topic-day{cursor:pointer}.topic-day:hover>rect:first-child{fill:#e8eef5}.topic-name{display:flex;align-items:center;gap:4px}.topic-name h3{margin:0}.topic-name>span{margin-left:auto;font-size:12px;color:#8795a4}.keywords{display:flex;flex-wrap:wrap;gap:5px;margin-top:12px}.keywords .chip{font-size:11px}.topic-sample{display:block;width:100%;text-align:left;border:0;border-top:1px solid #e2e8ed;border-radius:0;padding:12px 0;background:transparent}.topic-sample>span{font-size:11px;color:#4268ad}.topic-sample small{display:block;color:#8c99a6;font-size:10px;margin:5px 0}.topic-sample p{font-size:13px;line-height:1.8;margin:0;color:#53687d}.model-note{font-size:12px;color:#7a8897;line-height:1.8;margin-top:15px}.model-note summary{cursor:pointer}.model-note p{overflow-wrap:anywhere}@media(max-width:1450px){.topic-layout{grid-template-columns:1fr}.topic-description{border-top:1px solid #e0e7ed;padding-top:14px}}
</style>
