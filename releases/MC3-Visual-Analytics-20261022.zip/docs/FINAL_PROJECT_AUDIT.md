# 当前项目实现验收

日期：2026-10-22。范围：系统实现、分析支撑、项目文档与运行交付。用户明确暂不处理课程 PPT、个人总结和课程提交包，它们不属于本次完成范围。本文取代旧验收记录中的当前状态声明。

## 实现结果

| 分析任务 | 当前实现与核验依据 |
|---|---|
| 通信节奏与影响调查 | 14×24 热力图、逐日趋势、单日主体泳道、异常基线、方向与原文联动；相同双方附近 24 小时消息可回查，先后关系不自动解释为因果 |
| 群体及主题 | 社区力布局、有向矩阵、内部/跨群通信计数、4/6/8 主题模型、群体—主题矩阵；所选群体的计数、代表原文、消息集合和导出使用相同范围 |
| 人物/船舶候选 | 同类比较、可调权重、特征贡献、支持与反证、人工备注；另列原图人员—船舶角色和前后时段画像，保留原边、原文及来源哈希 |
| 主体与事件溯源 | 事件日期概览和泳道覆盖当前筛选的全部事件，列表独立分页；缺失和异常时间保留；每个支持消息可回到原文 |
| 来源风险 | 自环、同文节点、有限规则识别的自称/发送端点冲突、计划时间风险在阅读器可见；不改写官方端点、日期或消息 |
| 使用与交付 | 三工作区、联动筛选、撤销、桌面双图并排、单图放大、固定证据栏；完整消息 JSON、自包含 HTML 和分模块导出；Windows 后台启动/停止脚本 |

当前分析见 [CURRENT_ANALYSIS.md](CURRENT_ANALYSIS.md) 与 [当前机器快照](CURRENT_ANALYSIS.json)，主题专项见 [TOPIC_QUALITY_REVIEW.md](TOPIC_QUALITY_REVIEW.md)。[四题分析底稿](MC3_ANALYSIS_DRAFT.md) 与 [源证据快照](MC3_ANALYSIS_EVIDENCE.json) 保留第二阶段旧模型记录，不作为当前主题计数；不确认身份答案。

## 已执行验证

| 环境/检查 | 结果及范围 |
|---|---|
| Windows 11 / PowerShell 7 / Python 3.11.9 | 后端 32 passed；1 条 Starlette/httpx 上游弃用提示，无失败 |
| WSL2 Ubuntu / Python 3.12 | 当前后端 32 passed；同一弃用提示 |
| Windows 与 WSL 原生前端构建 | 当前源码类型检查与 Vite 生产构建均通过；复用各平台已有依赖，未覆盖另一平台的 node_modules |
| Windows Microsoft Edge / Playwright | 六个脚本共 48 组通过：e2e 20、redesign 9、topic-scope 7、investigation 4、workbench 3、analysis-tasks 5；最后一处仅调整放大主题布局，workbench 最终 3 组已复跑通过 |
| 主题专项 | 4/6/8 主题各 21 组扰动，共 63 组，另读默认 6 主题的 18 条代表原文；这不是准确率测试，结果显示明显样本敏感性 |
| 四题操作与导出 | 真实 HTTP 页面完成密集小时→原文→报告、群体→主题→模型导出、人物/船舶比较、Nadia 全事件→离线报告；延迟响应下验证事件导出不会把新条件附到旧列表 |
| 实际视觉复查 | 三工作区 1920×1080 和 1366×768；本轮更新群体截图，额外检查大屏主题放大后的矩阵/原文并排；事件日期概览保持紧凑 |
| 独立目录运行包 | ZIP 解压到 work/release-check-20261022-quality，确认 ROOT 指向解包目录；独立 8002 服务通过后端 32 项与浏览器 39 组（20+7+4+3+5）；临时服务已安全停止，原 8000 服务仍正常 |

本轮新增测试先复现了主题范围错配、来源提示缺失、分页事件图覆盖不足、放大概览过高和群体计数缺失，再修改对应实现。没有把历史 WSL 浏览器结果当作当前版本通过证据。浏览器脚本位于 frontend/tests，运行命令见 [README](../README.md)。

成品截图：[通信模式](screenshots/final-patterns-1920.png)、[群体主题](screenshots/final-groups-1920.png)、[调查工作区](screenshots/final-investigation-1920.png)、[小屏群体](screenshots/final-groups-1366.png)、[来源检查](screenshots/final-source-checks.png)、[分时段画像](screenshots/final-period-profiles.png)、[放大事件](screenshots/final-events-overview.png)、[当前主题放大比较](screenshots/final-topic-quality.png)。这些是真实运行页面，不是设计稿；未改变的工作区截图沿用上一阶段。

## 质量判断与剩余边界

- 工程已覆盖既定系统任务；范围一致性、原文回查和空范围行为有针对性回归。当前实现与运行交付验收完成，方法上的不确定性继续保留。
- 视觉上，社区布局与桌面并排明显改善了原来的圆周交叉边和纵向长页面；密集网络仍需邻域、矩阵或放大辅助，浅色小字不适合未经调节的远距离投影。没有用户研究证明交互效率，也不把自动化通过等同优秀作品级视觉质量。
- NMF 已完成 63 组扰动及代表原文评估；缩写碎片已清理，泛词、局部最优与样本敏感性仍存在。默认 6 主题移除 4 条重复正文后，236/584 条最大因子归属改变。因此主题是探索表征，编号不是稳定类别，不能包装成稳定组织或语义真值。
- 候选分数不是概率。Boss 在去掉文本特征后首名改变；前后两段画像仅提供共享操作者的调查入口，不能确认身份、共享化名或无线电操作者。
- 自称冲突规则只覆盖有限句式且要求姓名唯一，可能漏报；不以该启发式自动纠正官方记录。同文节点与自环保留，不能直接算作独立佐证。
- 原图事件/角色来自文本推断；时间先后与附近通信不证明行动完成或因果。Nadia 的隐瞒与协调有具体通信支持，具体违法及持续非法捕鱼仍未证实。
- 数据缺少经纬度、身份真值和独立现场观察；这些证据缺口不会通过增加图表或调权消失。

## 数据与复现口径

唯一事实输入：data/raw/MC3_release.zip；SHA-256：`ca62ea3d0605b05b57b2a9b6c824da67d6ab47e3e714069bfd69f0963380c9d6`。原图 1,159 节点、3,226 边、584 条通信；通信投影 41 主体、217 个有向联系。保留 32 个缺失事件时间、81 条无 evidence_for 通信、31 条自环及 4 对相同正文。源 ZIP 未修改。

运行入口与锁定依赖见 [README](../README.md)，API 新字段见 [API](API.md)，设计选择见 [设计依据](DESIGN_RATIONALE.md)，演进中的缺陷及修复见 [批判性评审](CRITICAL_REVIEW.md)。

## 运行源码包

交付文件：releases/MC3-Visual-Analytics-20261022.zip；SHA-256 随同名 .sha256 文件提供。包内包含源码、测试、锁文件、官方数据、处理表、已构建前端、启动/准备脚本及项目文档。第二阶段五张分析截图已复制到 docs/screenshots/analysis，底稿图片改为相对链接。

排除开发虚拟环境、node_modules、运行缓存、work、外部参考项目及 releases 自身。独立目录验收复用本机已安装 Python 依赖和 Edge；不代表验证了全新电脑上的联网安装。临时服务读取解包目录的数据与前端；浏览器测试由开发目录的现有 Playwright 发起，实际请求地址为 8002。redesign 的 9 组在原 8000 服务验证，不计入独立包的 39 组。

最后仅同步文档与测试报告并重新封装，后端、前端源码/构建、测试、配置和运行脚本与已验收副本逐文件哈希一致。可核验结果及该组文件哈希见 [release-verification.json](release-verification.json)。

## 本轮修改文件与回归重点

主题噪声与评估：backend/app/topics.py、backend/tests/test_topics.py、scripts/review_topics.py；事件导出范围与来源：backend/app/events.py、backend/tests/test_events.py、frontend/src/components/EventView.vue、frontend/src/api.ts；界面与任务验证：frontend/src/components/TopicView.vue、frontend/src/style.css、frontend/tests/analysis-tasks.mjs、frontend/tests/workbench.mjs；当前分析重算：scripts/export_analysis.py。文档、快照和 dist 随实现同步。

新增回归关注：三种主题数不含缩写碎片；筛选不重训；局部/全局条件快速变化、空范围和延迟响应下的事件导出；全范围事件不随列表分页改变；大屏主题放大并排；四题当前原文、消息集合、模型版本和来源哈希与导出一致。未发现这些路径仍有失败，不承诺所有未知输入或未来浏览器版本均无缺陷。
