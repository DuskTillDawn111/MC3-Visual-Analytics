# 当前项目实现验收

日期：2026-10-23。范围为系统实现、分析支撑、项目文档与运行交付；课程 PPT、个人总结和课程提交包不在本次范围。本文替代旧文档中的当前状态声明。

## 本轮完成内容

| 原问题 | 当前实现与验证依据 |
|---|---|
| 刷新失败仍显示同步、报告混用范围 | 失败显示未同步，暂停旧图交互；全局与可见子模块加载完成才能导出；快速切换、延迟及部分失败有回归 |
| 唯一通信数和加权度混用、自环不可见 | 列表、详情和图统一唯一通信数；发送/接收/自环分列；自环弧线支持鼠标或键盘回查 |
| 主题比较受规模影响，8 色重复，仅检查典型样本 | 增加群内占比及分母、8 种独立颜色、边界与固定种子抽样；复核 24 条原文并导出抽样方式与因子权重 |
| 候选证据与特征联系不清、敏感性不在界面 | 联系人/小时/上下文/共享词均附两侧来源；可查看特征移除、同文去重和逐日留出排序；自定义分段可导出 |
| 小屏重点不突出、事件图横向溢出 | 候选摘要前置、默认前三名、提高关键文字对比度、事件泳道适配面板并优先选中主体；人工记录刷新后保持展开 |
| 四题分析仅在文档 | 新增四题分析卡片、竞争解释、证据缺口及 Nadia 四阶段时间线；点击恢复调查条件，JSON/HTML 保留论证与原始消息 |

默认权重和 NMF v3 未为追求预设身份答案而调整。官方原文、端点、异常年份、自环和相同正文记录保留。

## 已执行验证

| 检查 | 结果及范围 |
|---|---|
| Windows / Python 3.11 后端 | 37 passed；1 条 Starlette/httpx 上游弃用提示，无失败 |
| WSL2 / Python 3.12 后端 | 当前源码 37 passed；复用 /tmp/mc3-audit-20261021/venv。最初 work/wsl-venv 缺少 pytest，改用已有依赖环境后通过 |
| Windows 前端 | vue-tsc 与 Vite 生产构建通过；依赖锁文件未修改。当前版本未重跑 WSL 原生前端构建 |
| Edge 生产页面 | 十个脚本共 59 组通过：e2e 20、redesign 9、topic-scope 7、investigation 4、workbench 3、analysis-tasks 5、reliability 6、investigation-quality 3、findings 1、topic-sampling 1 |
| 视觉复查 | 三工作区在 1366×768、1920×1080 加载完成后截图复查，无页面横向溢出；截图见 screenshots/improvements |
| 主题复核 | 原 v3 的 63 组扰动仍适用；新增六主题各 2 条边界、2 条固定种子样本，共 24 条 AI 辅助原文复核，不是独立人工标注准确率 |
| 独立目录运行包 | work/release-check-20261023 的 ROOT、584 条通信及源哈希已核验；后端 37 项及同一批 59 组浏览器检查全部通过；记录见 release-verification.json |
| Windows 后台启停 | 无可见窗口、重复启动幂等、停止、重启、生产页面与官方数据均通过 |
| 真实用户走查 | 已准备 USER_WALKTHROUGH.md，负责人同意安排同学；尚无参与者结果，不能宣称已验证学习成本或效率 |

浏览器曾发现两项问题：旧缩放测试在同步保护期间发送滚轮，已改为等待可交互状态；候选刷新收起人工记录区，先新增失败测试，再保存展开状态并复验通过。

## 结论与边界

- 四题论证见 CURRENT_ANALYSIS.md，界面卡片由 backend/app/findings.py 提供，保留来源和竞争解释。468/584 条通信集中于 08:00–11:59；四群体内部 464 条、跨群 120 条，不证明组织身份或因果。
- 默认六主题移除四条重复正文后，236/584 条最大因子归属变化，主题编号不是稳定类别。抽样让不确定性可检查，不会消除它。
- Boss 默认 Nadia 与 Elise 接近，移除文本首名改变。接收语境、转述及共同任务影响相似性；得分不是概率，分时变化不确认共享操作者。
- Nadia 原文支持隐瞒、协调、设备及许可活动的调查线索；指令与执行、许可自述与独立核验仍有缺口，不确认具体违法或持续非法捕鱼。
- 密集网络仍需邻域/矩阵/放大；易学性需要真实用户反馈，不能把自动测试当作视觉质量或封版依据。
- 无经纬度、身份真值或独立现场观察；推断关系与来源原文不是独立的两份证据。
- 本机循环测量中候选接口约 1.6 秒，敏感性按需执行；不是并发负载测试或生产 SLA。

## 数据与运行包

唯一事实输入 data/raw/MC3_release.zip，SHA-256：`ca62ea3d0605b05b57b2a9b6c824da67d6ab47e3e714069bfd69f0963380c9d6`。原图 1,159 节点、3,226 边、584 条通信；投影 41 主体、217 个有向联系。保留 32 个缺失事件时间、81 条无 evidence_for 通信、31 条自环及 4 对相同正文。

运行源码包：releases/MC3-Visual-Analytics-20261023.zip，附同名 .zip.sha256。包括源码、测试、锁文件、官方数据、处理表、生产前端、脚本和文档；排除虚拟环境、node_modules、缓存、work、releases 自身。入口为 start.ps1/stop.ps1。

独立验证复用本机 Python 依赖和 Edge/Playwright，浏览器测试从开发目录请求解包后的 8002 服务，不代表全新电脑联网安装验证。最后仅同步文档并重新封装；运行源码、测试、配置、数据与构建产物须逐文件哈希匹配已验证副本。机器记录见 [release-verification.json](release-verification.json)。

## 修改文件与后续复测

后端：app/graph.py、main.py、aliases.py、findings.py，及 tests/test_graph.py、test_aliases.py、test_findings.py。前端：App.vue、api.ts、store.ts、report.ts、style.css，NetworkView、TopicView、AliasView、EventView、TemporalView、FindingsPanel；测试 e2e、investigation、reliability、investigation-quality、findings、topic-sampling。抽样：scripts/sample_topic_evidence.py。README、API、设计依据、当前分析、抽样复核、走查表、机器快照与 dist 同步更新。

后续真实反馈优先复测：不同群体的数量/占比理解、身份分数误解、两侧原文追踪、指令与完成区分、分析卡片与消息附录范围。记录匿名卡点、处理和复测，不能把待执行项目记为通过。
