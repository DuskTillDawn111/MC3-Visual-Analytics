"""Authored interpretations with computed statistics and explicit source records.

These are investigation starting points, never inferred identity or legal truth.
"""
from functools import lru_cache
from statistics import median

from .data import dataset as d
from .graph import graph
from .aliases import aliases, DEFAULT_WEIGHTS


def sources(ids):
    return [d.message_index[f'Event_Communication_{number}'] for number in ids]


def clock_median(rows):
    seconds = [sum(int(value) * factor for value, factor in zip(m['timestamp'][11:19].split(':'), (3600, 60, 1))) for m in rows]
    value = int(median(seconds))
    return f'{value // 3600:02}:{value % 3600 // 60:02}'


@lru_cache(maxsize=1)
def findings():
    graph_data = graph({})
    morning = sum(8 <= message['hour'] < 12 for message in d.messages)
    internal = sum(group['internal_communications'] for group in graph_data['communities'])
    candidates = aliases('Boss', {})['items']
    ablated = aliases('Boss', {}, dict(DEFAULT_WEIGHTS, text=0))['items']
    scope = dict(start=d.days[0], end=d.days[-1], hour=None, q='', entity='')

    def card(key, title, workspace, claim, counter, limitation, evidence, stats, stages=None):
        return dict(id=key, title=title, level='author_analysis', claim=claim,
                    competing_explanation=counter, limitation=limitation, statistics=stats,
                    evidence=sources(evidence), stages=stages or [],
                    state=dict(workspace=workspace, filters=dict(scope, entity='Nadia Conti' if key == 'nadia' else ''),
                               message_ids=[m['id'] for m in sources(evidence)],
                               alias='Boss' if key == 'identity' else None))

    cards = [
        card('rhythm', '通信集中在上午；影响关系须检查指令与回应', 'patterns',
             f'{morning}/{len(d.messages)} 条消息出现在 08:00–11:59。两周的通信时间中位数接近，不能据此宣称整体明显后移。161/162 展示指令与回应，可作为影响关系的具体线索。',
             '记录覆盖、无线电工作安排也可能造成上午集中。回复指令不等于对方在全部事务上受到控制。',
             '通信发送时间与原文约定的行动时间不同；短观察窗不能估计因果影响。', [161, 162],
             dict(morning_messages=morning, total_messages=len(d.messages),
                  first_week_median=clock_median([m for m in d.messages if m['date'] <= d.days[6]]),
                  second_week_median=clock_median([m for m in d.messages if m['date'] > d.days[6]]))),
        card('groups', '紧密通信群体不等于固定组织或一致立场', 'groups',
             f'全期分为 {len(graph_data["communities"])} 个通信社区：内部消息 {internal} 条，跨群消息 {len(d.messages)-internal} 条。应结合主题占比和双方角色解释群体差异。',
             '环境质疑方与行政方可能因频繁往来处于同群；主题相似也可能来自转述。',
             '社区随筛选改变；主题对样本扰动敏感。跨群消息进入双方主题行，不能跨行求和。', [460, 733, 161, 126],
             dict(communities=len(graph_data['communities']), internal=internal, cross_group=len(d.messages)-internal)),
        card('identity', 'Boss 的首名候选依赖文本特征', 'investigation',
             f'默认首名为 {candidates[0]["candidate"]}，移除文本特征后为 {ablated[0]["candidate"]}。这种变化说明排名依赖建模选择，不能把首名当作身份答案。',
             '共同联系人、接收相似消息和任务合作，都可能产生相似画像；一个称呼也可能由多人使用。',
             '候选得分不代表身份概率。缺少身份锚点时，只记录待核查假设与竞争解释。', [529, 535, 21, 22],
             dict(default_top=candidates[0]['candidate'], without_text_top=ablated[0]['candidate'],
                  default_candidates=[dict(candidate=r['candidate'], score=r['score']) for r in candidates[:3]])),
        card('nadia', '隐瞒与协调值得调查；具体违法仍未证实', 'investigation',
             'Nadia 的通信包含销毁文件指令、有偿协调和调整作业安排。它们支持继续调查隐瞒与协调行为，但不证明这些行动已实施或持续非法捕鱼。',
             '334 给出时间冲突解释，536 表示工程超出原约定，575 提供许可与合法运输的自述；均需核查，不能视作免责证明。',
             '缺少独立的付款、施工、文件销毁和许可核验记录。派生事件与其来源通信不能算两份独立证据。',
             [331, 334, 529, 535, 536, 575, 847, 943],
             dict(direct_messages=len(d.filter_messages(entity_id='Nadia Conti'))), [
                 dict(date='2040-10-05', claim='取消通道并要求销毁文件', support_ids=['Event_Communication_331'],
                      counter_ids=['Event_Communication_334'], gap='有指令，无独立的执行记录。'),
                 dict(date='2040-10-08', claim='提出加倍报酬；对方自述调整巡逻', support_ids=['Event_Communication_529', 'Event_Communication_535'],
                      counter_ids=['Event_Communication_536', 'Event_Communication_575'], gap='付款未核实；对原工程范围和许可存在竞争解释。'),
                 dict(date='2040-10-12', claim='自述文件完成并建议加速、转移作业', support_ids=['Event_Communication_847'],
                      counter_ids=[], gap='此消息没有 evidence_for，原文仍须保留；完成自述没有独立核验。'),
                 dict(date='2040-10-14', claim='收到水下照明的最终批准请求', support_ids=['Event_Communication_943'],
                      counter_ids=[], gap='收到请求不等于已经批准或完成安装。'),
             ]),
    ]
    return dict(source_sha256=d.source_hash, analysis_version='review-2026-10-23', items=cards,
                scope='Full official 14-day corpus and default model parameters; interpretations do not automatically change with UI filters.')
