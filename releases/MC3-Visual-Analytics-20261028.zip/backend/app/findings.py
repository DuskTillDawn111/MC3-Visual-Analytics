"""Authored interpretations with computed statistics and explicit source records.

These are investigation starting points, never inferred identity or legal truth.
"""
from functools import lru_cache
from statistics import median

from .data import dataset as d
from .graph import graph
from .aliases import aliases, DEFAULT_WEIGHTS


def sources(ids):
    return [d.message_index[f'Event_Communication_{number}'] for number in ids]


def clock_median(rows):
    seconds = [sum(int(value) * factor for value, factor in zip(m['timestamp'][11:19].split(':'), (3600, 60, 1))) for m in rows]
    value = int(median(seconds))
    return f'{value // 3600:02}:{value % 3600 // 60:02}'


@lru_cache(maxsize=1)
def findings():
    graph_data = graph({})
    morning = sum(8 <= message['hour'] < 12 for message in d.messages)
    internal = sum(group['internal_communications'] for group in graph_data['communities'])
    candidates = aliases('Boss', {})['items']
    ablated = aliases('Boss', {}, dict(DEFAULT_WEIGHTS, text=0))['items']
    scope = dict(start=d.days[0], end=d.days[-1], hour=None, q='', entity='')

    def card(key, title, workspace, claim, counter, limitation, evidence, stats, stages=None):
        return dict(id=key, title=title, level='author_analysis', claim=claim,
                    competing_explanation=counter, limitation=limitation, statistics=stats,
                    evidence=sources(evidence), stages=stages or [],
                    state=dict(workspace=workspace, filters=dict(scope, entity='Nadia Conti' if key == 'nadia' else ''),
                               message_ids=[m['id'] for m in sources(evidence)],
                               alias='Boss' if key == 'identity' else None))

    cards = [
        card('rhythm', '通信集中在上午；影响关系须检查指令与回应', 'patterns',
             f'{morning}/{len(d.messages)} 条消息出现在 08:00–11:59。两周的通信时间中位数接近，不能据此宣称整体明显后移。161/162 展示指令与回应，可作为影响关系的具体线索。',
             '记录覆盖、无线电工作安排也可能造成上午集中。回复指令不等于对方在全部事务上受到控制。',
             '通信发送时间与原文约定的行动时间不同；短观察窗不能估计因果影响。', [161, 162],
             dict(morning_messages=morning, total_messages=len(d.messages),
                  first_week_median=clock_median([m for m in d.messages if m['date'] <= d.days[6]]),
                  second_week_median=clock_median([m for m in d.messages if m['date'] > d.days[6]]))),
        card('groups', '紧密通信群体不等于固定组织或一致立场', 'groups',
             f'全期分为 {len(graph_data["communities"])} 个通信社区：内部消息 {internal} 条，跨群消息 {len(d.messages)-internal} 条。应结合主题占比和双方角色解释群体差异。',
             '环境质疑方与行政方可能因频繁往来处于同群；主题相似也可能来自转述。',
             '社区随筛选改变；主题对样本扰动敏感。跨群消息进入双方主题行，不能跨行求和。', [460, 733, 161, 126],
             dict(communities=len(graph_data['communities']), internal=internal, cross_group=len(d.messages)-internal)),
        card('identity', 'Boss 的首名候选依赖文本特征', 'investigation',
             f'默认首名为 {candidates[0]["candidate"]}，移除文本特征后为 {ablated[0]["candidate"]}。这种变化说明排名依赖建模选择，不能把首名当作身份答案。',
             '共同联系人、接收相似消息和任务合作，都可能产生相似画像；一个称呼也可能由多人使用。',
             '候选得分不代表身份概率。缺少身份锚点时，只记录待核查假设与竞争解释。', [529, 535, 21, 22],
             dict(default_top=candidates[0]['candidate'], without_text_top=ablated[0]['candidate'],
                  default_candidates=[dict(candidate=r['candidate'], score=r['score']) for r in candidates[:3]])),
        card('nadia', '隐瞒与协调值得调查；具体违法仍未证实', 'investigation',
             'Nadia 的通信包含销毁文件指令、有偿协调和调整作业安排。它们支持继续调查隐瞒与协调行为，但不证明这些行动已实施或持续非法捕鱼。',
             '334 给出时间冲突解释，536 表示工程超出原约定，575 提供许可与合法运输的自述；均需核查，不能视作免责证明。',
             '缺少独立的付款、施工、文件销毁和许可核验记录。派生事件与其来源通信不能算两份独立证据。',
             [331, 334, 529, 535, 536, 575, 847, 943],
             dict(direct_messages=len(d.filter_messages(entity_id='Nadia Conti'))), [
                 dict(date='2040-10-05', claim='取消通道并要求销毁文件', support_ids=['Event_Communication_331'],
                      counter_ids=['Event_Communication_334'], gap='有指令，无独立的执行记录。'),
                 dict(date='2040-10-08', claim='提出加倍报酬；对方自述调整巡逻', support_ids=['Event_Communication_529', 'Event_Communication_535'],
                      counter_ids=['Event_Communication_536', 'Event_Communication_575'], gap='付款未核实；对原工程范围和许可存在竞争解释。'),
                 dict(date='2040-10-12', claim='自述文件完成并建议加速、转移作业', support_ids=['Event_Communication_847'],
                      counter_ids=[], gap='此消息没有 evidence_for，原文仍须保留；完成自述没有独立核验。'),
                 dict(date='2040-10-14', claim='收到水下照明的最终批准请求', support_ids=['Event_Communication_943'],
                      counter_ids=[], gap='收到请求不等于已经批准或完成安装。'),
             ]),
    ]
    changes = []
    for entity in ['Boss', 'Nadia Conti', 'The Intern', 'The Lookout', 'Mako', 'Mrs. Money']:
        rows = d.filter_messages(entity_id=entity)
        first = [m for m in rows if m['date'] <= d.days[6]]
        second = [m for m in rows if m['date'] > d.days[6]]
        changes.append(dict(entity=entity, first_count=len(first), second_count=len(second),
                            first_median=clock_median(first), second_median=clock_median(second),
                            message_ids=[m['id'] for m in rows]))
    cards[0]['statistics']['entity_changes'] = changes
    cards[0]['claim'] = ('整体通信集中在上午，但主体变化方向不同：Nadia 两周参与消息由 6 条增至 20 条，'
                         'Boss 由 25 条降至 5 条。对具体影响关系，161/162 展示 Mrs. Money 的情报要求和 The Intern 一分钟后的回应。')
    notes = [
        (331, '销毁文件指令', 'Destroy all related documentation.', '取消特殊通道与销毁文件出现在同一指令中，为隐瞒行为提供调查线索。'),
        (334, '时间冲突解释', 'My cancellation was due to scheduling conflicts', '四分钟后，对 Council 的解释转为旅游项目时间冲突，同时自述此前不知道许可获批。'),
        (529, '提出加倍报酬', 'Double your usual fee', '要求维持 Harbor Master 的配合，并约定次日晚间见面。通信记录的是请求与安排。'),
        (535, '巡逻调整自述', "implemented new patrol schedules that work in our favor", 'Liam 回复确认会面，自述已转移注意力并调整巡逻；付款与实际调整仍待独立核查。'),
        (536, '工程范围异议', 'This extends beyond our agreed scope.', 'Nadia 询问水下基础工程，表示超出约定范围。这使其知情范围成为需要进一步检查的问题。'),
        (575, '合法运输自述', "We're operating under permit #CR-7844, not NR-1045.", 'Mako 向 Sentinel 解释许可与运输合法性。这是关联主体的说法，供交叉核对。'),
        (847, '加速与转移安排', 'Recommend accelerating timeline due to EcoVigil', '自述许可文件完成，并把加速、转移安排与 EcoVigil 的 ROV 审批联系起来。'),
        (943, '最终批准请求', 'Need final approval for underwater lighting placement', 'Remora 请求水下照明的最终批准，表明相关协调继续推进；后续批准和安装记录待补。'),
    ]
    cards[3]['source_notes'] = [dict(id=f'Event_Communication_{n}', label=label, excerpt=excerpt, reading=reading)
                               for n, label, excerpt, reading in notes]
    def step(observation, interpretation, ids):
        return dict(observation=observation, interpretation=interpretation,
                    message_ids=[f'Event_Communication_{n}' for n in ids])
    cards[0]['reasoning_steps'] = [
        step('全期 468/584 条通信在 08:00–11:59；两周中位时间为 10:23 / 10:27。',
             '全体稳定的节奏掩盖主体参与量的变化；需要按主体观察。', []),
        step('Nadia 由 6 条增至 20 条，Boss 由 25 条降至 5 条。',
             '调查重心可转向 Nadia 后一周的联系人与活动，再检查双方记录覆盖。', [529, 535, 847, 943]),
        step('161 的情报要求在 162 得到“as requested”的回应，相隔一分钟。',
             '这组内容支持本次任务中的指令—回应联系；继续以其他往来检查关系是否持续。', [161, 162])]
    cards[1]['reasoning_steps'] = [
        step('四个通信社区内部 464 条，跨群 120 条。', '同时检查群内联系和跨群沟通，保留桥梁主体。', [460, 733]),
        step('六主题模型中，社区 2 的主题 5 为 92/255，社区 4 为 23/38。',
             '前者数量更多，后者占比更高（36.1% / 60.5%）；群体规模与内容集中度分别比较。', [751]),
        step('751 同时涉及部署、设备调整与 ROV 许可延迟。',
             '原文呈现混合任务；将主题作为阅读入口，并结合角色解释群体。', [751])]
    cards[2]['reasoning_steps'] = [
        step('Boss 默认首名为 Nadia，移除文本特征后首名为 Elise。',
             '先保留两个身份假设，再检查两种解释对活动网络的影响。', [21, 22, 529, 535]),
        step('21/22 涉及 Boss、Mrs. Money、The Middleman 的机会与资金讨论；529/535 涉及 Nadia 与 Liam 的报酬及巡逻安排。',
             '若 Boss 与 Nadia 为同一人，这两组活动可能经同一操作者衔接；若为不同人，则需要继续寻找联络桥梁。此处展示假设的解释后果。', [21, 22, 529, 535]),
        step('866 是发给 Boss 的消息，724 是发给 Elise 的消息。',
             '收到相近语境也会产生文本相似；回查发送角色后，降低仅凭措辞识别身份的权重。', [866, 724])]
    cards[3]['reasoning_steps'] = [
        step('331 要求销毁文件，334 给出时间冲突解释。', '同日不同对象的说法构成首先需要核对的张力。', [331, 334]),
        step('529/535 串联报酬、会面与巡逻调整自述；536/575 补充工程范围和许可说法。',
             '判断由单条文件指令扩展为持续协调的调查假设，同时保留知情范围与合法作业解释。', [529, 535, 536, 575]),
        step('847 涉及加速和转移，943 仍向 Nadia 请求最终批准。',
             '记录支持继续追查 Nadia 的协调角色；下一步核对付款、巡逻、许可及实际执行。', [847, 943])]
    return dict(source_sha256=d.source_hash, analysis_version='review-2026-10-28', items=cards,
                scope='Full official 14-day corpus and default model parameters; interpretations do not automatically change with UI filters.')
